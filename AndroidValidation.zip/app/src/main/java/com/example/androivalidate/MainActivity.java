package com.example.androivalidate;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    EditText displayDate;
    Button btnSubmit;
    Spinner properties;
    EditText monthlyRentPrice;
    Spinner furnitureType;
    EditText bedRooms;
    EditText nameReporter;
    EditText notes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSubmit = (Button) findViewById(R.id.btn_submit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] arrValidate = {};
                List<String> listValidate = new ArrayList<>(Arrays.asList((arrValidate)));

                String[] listProperties = {"Flat", "House", "Bungalow"};
                String[] listFurnished = {"Furnished", "Unfurnished", "Part Furnished"};

                List<String> listPropertyType = new ArrayList<>(Arrays.asList(listProperties));
                List<String> listFurnitureTypes = new ArrayList<>(Arrays.asList(listFurnished));

                properties = findViewById(R.id.property_type);
                String valPropertyType = properties.getSelectedItem().toString();

                bedRooms = findViewById(R.id.bed_room);
                String valBedrooms = bedRooms.getText().toString();

                displayDate = findViewById(R.id.dateTimeEdit);
                String valDateTimeAdding = displayDate.getText().toString();

                monthlyRentPrice = findViewById(R.id.monthly_rent_price);
                String valMonthlyRentPrice = monthlyRentPrice.getText().toString();

                furnitureType = findViewById(R.id.furnishture_type);
                String valFurnitureTypes = furnitureType.getSelectedItem().toString();

                notes = findViewById(R.id.notes_input);
                String valNotes = notes.getText().toString();

                nameReporter = findViewById(R.id.reporter);
                String valNameReporter = nameReporter.getText().toString();

                if (!(listPropertyType.contains(valPropertyType))) {
                    listValidate.add("Property Type");
                }
                if(!(isNumber(valBedrooms))){
                    listValidate.add("Bed room");
                }
                if (!(isValidateDate(valDateTimeAdding))) {
                    listValidate.add("Date Time");
                }

                if (!(isNumber(valMonthlyRentPrice))) {
                    listValidate.add("Monthly Rent Price");
                }

                if (isEmptyOrWhiteSpace(valNameReporter)) {
                    listValidate.add("Name Reporter");
                }

                if (listValidate.size() > 0) {
                    Toast makeToast = Toast.makeText(MainActivity.this, errMessage(listValidate), Toast.LENGTH_LONG);
                    makeToast.show();
                } else {
                    Toast makeToast = Toast.makeText(MainActivity.this, "You have successfully created the form!", Toast.LENGTH_LONG);
                    makeToast.show();
                }
            }
        });
    }

    public final static String errMessage(List isValidate) {
        String err = "";
        for (int i = 0; i < isValidate.size(); i++) {
            err += (isValidate.get(i) + ", ");
        }

        return "You need to enter " + err  + "\n";
    }

    public final static boolean isValidateDate(String el)
    {
        return Pattern.compile("^\\d{4}[\\/.]\\d{1,2}[\\/.]\\d{1,2}$").matcher(el).matches();
    }

    public final static boolean isEmptyOrWhiteSpace(String el)
    {
        return Pattern.compile("^\\s*$").matcher(el).matches();
    }

    public final static boolean isNumber(String el)
    {
        return Pattern.compile("^\\d+$").matcher(el).matches();
    }
}